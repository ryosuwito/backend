Description: Data processing and entry (manual or use python)

For each row in make_model file, there are two columns: "Make" and "Model". Your job is to find the corresponding rows in parent_brand_nameplate file and append those rows in the make_model file. 

For most of the time, "Make" is the same concept as "Sales Parent"/"Sales Brand" columns in parent_brand_nameplate file, while "Model" should be corresponding to "Sale Nameplate" column. After you find corresponding row in parent_brand_nameplate file, you just append the row into make_model.csv. If you think there are more than one rows in parent_brand_nameplate file can be mapped into one row in make_model file, you just add more rows for them. For those can't find correrponding rows, append empty rows for them. 

Here are the samples:
- For (Volkswagen,Phaeton) row in make_model file, there is only one corresponding row in the parent_brand_nameplate file: (Volkswagen,Volkswagen,Phaeton), so you just append (Volkswagen,Volkswagen,Phaeton) beside the (Volkswagen,Phaeton) row in the make_model file.

- For (Volkswagen,Passat) row in make_model file, there are quite a few corresponding rows in the parent_brand_nameplate file: (Volkswagen,Volkswagen,Passat), (Volkswagen,Volkswagen,Passat Alltrack), (Volkswagen,Volkswagen,Passat CC), (Volkswagen,Volkswagen,Passat (LCV)), ((Volkswagen,Volkswagen,Passat Lingyu), so for each of these row, you need to prepare one row in the make_model file. 

- For (AMC, Alliance) row, no corresponding row is found, so you should append empty contents for them.

In summary, for these three pairs, you should produce a file like below:

Make,Model,Sales Parent,Sales Brand,Sales Nameplate
Volkswagen,Phaeton,Volkswagen,Volkswagen,Phaeton
Volkswagen,Passat,Volkswagen,Volkswagen,Passat
Volkswagen,Passat,Volkswagen,Volkswagen,Passat Alltrack
Volkswagen,Passat,Volkswagen,Volkswagen,Passat CC
Volkswagen,Passat,Volkswagen,Volkswagen,Passat (LCV)
Volkswagen,Passat,Volkswagen,Volkswagen,Passat Lingyu
AMC,Alliance,,,

Please try to map as much records as possible in 4 hours, then send the csv of results back. If you are using some scripts, please share the script as well.
